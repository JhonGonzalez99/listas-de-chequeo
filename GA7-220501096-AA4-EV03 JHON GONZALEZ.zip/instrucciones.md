# INSTRUCCIONES PARA EJECUTAR EL PROYECTO DE LOGIN

## REQUISITOS PREVIOS

### Software necesario:
- **Node.js** (versión 18 o superior)
- **npm** o **pnpm** (recomendado pnpm)
- **MongoDB Atlas** (base de datos en la nube)

### Verificar instalación:
```bash
node --version
npm --version
# o
pnpm --version
```

---

## CONFIGURACIÓN DEL BACKEND

### 1. Instalar dependencias
```bash
cd backend
pnpm install
```

### 2. Configurar variables de entorno
Crear archivo `.env` en la carpeta `backend/`:
```env
DATABASE_URL="mongodb+srv://tu_usuario:tu_password@tu_cluster.mongodb.net/tu_base_de_datos?retryWrites=true&w=majority"
PORT=3000
NODE_ENV=development
```

**Nota:** Reemplaza la URL con tu conexión de MongoDB Atlas.

### 3. Configurar Prisma
```bash
# Generar el cliente de Prisma
npx prisma generate

# Sincronizar el esquema con la base de datos
npx prisma db push
```

### 4. Ejecutar el servidor
```bash
pnpm start
```

El backend estará disponible en: `http://localhost:3000`

---

## EXPLICACIÓN DEL BACKEND

### Estructura del proyecto:
```
backend/
├── src/
│   ├── controllers/     # Lógica de negocio
│   ├── middlewares/     # Validaciones y middleware
│   ├── routes/          # Definición de rutas
│   ├── utils/           # Utilidades (DB, hash)
│   └── server.js        # Servidor principal
├── prisma/
│   └── schema.prisma    # Esquema de base de datos
└── package.json
```

### Tecnologías utilizadas:
- **Express.js**: Framework web para Node.js
- **Prisma**: ORM para MongoDB
- **bcrypt**: Hashing de contraseñas
- **express-validator**: Validación de datos
- **cors**: Middleware para CORS

### Base de datos (MongoDB Atlas):
- **Prisma** como ORM
- **Esquema**: Modelo User con id, name, email, password
- **Contraseñas**: Hasheadas con bcrypt
- **IDs**: ObjectIds de MongoDB

### Middleware de validación:
El archivo `validation.middleware.js` contiene:
- Validación de ObjectIds de MongoDB
- Validación de formularios de registro/login
- Validación de CRUD de usuarios
- Logging de errores de validación

### Endpoints disponibles:

#### Autenticación:
- **POST /api/auth/register**
  - Recibe: `{ name, email, password }`
  - Devuelve: `{ id, name, email }`
  - Validaciones: nombre obligatorio, email válido, password mínimo 6 caracteres

- **POST /api/auth/login**
  - Recibe: `{ email, password }`
  - Devuelve: `{ id, name, email }`
  - Validaciones: email válido, password obligatorio

#### Usuarios (CRUD):
- **GET /api/users** - Listar todos los usuarios
- **GET /api/users/:id** - Obtener usuario por ID
- **POST /api/users** - Crear usuario
- **PUT /api/users/:id** - Actualizar usuario completo
- **PATCH /api/users/:id** - Actualizar usuario parcialmente
- **DELETE /api/users/:id** - Eliminar usuario

### Flujo de autenticación:
1. Usuario envía credenciales
2. Middleware valida datos
3. Controller busca usuario en DB
4. Compara contraseña hasheada
5. Retorna datos del usuario (sin contraseña)

---

## CONFIGURACIÓN DEL FRONTEND

### 1. Instalar dependencias
```bash
cd client
pnpm install
```

### 2. Ejecutar en modo desarrollo
```bash
pnpm dev
```

El frontend estará disponible en: `http://localhost:5173`

---

## EXPLICACIÓN DEL FRONTEND

### Estructura del proyecto:
```
client/
├── src/
│   ├── components/      # Componentes reutilizables
│   │   ├── ui/          # Componentes de UI (shadcn/ui)
│   │   ├── layout.tsx   # Layout principal
│   │   └── theme-provider.tsx
│   ├── pages/           # Páginas de la aplicación
│   │   ├── home.tsx     # Panel de administración
│   │   ├── login.tsx    # Página de login
│   │   └── register.tsx # Página de registro
│   ├── lib/             # Utilidades
│   ├── App.tsx          # Componente principal
│   └── main.tsx         # Punto de entrada
└── package.json
```

### Tecnologías utilizadas:
- **React 19** con TypeScript
- **Vite** como bundler
- **React Router DOM** para navegación
- **React Hook Form** para formularios
- **Zod** para validación de esquemas
- **Axios** para peticiones HTTP
- **Tailwind CSS** para estilos
- **shadcn/ui** para componentes de UI
- **Radix UI** para componentes accesibles

### Sistema de formularios:

#### Login (`login.tsx`):
- **Validación**: Email válido, password mínimo 6 caracteres
- **Flujo**: 
  1. Usuario llena formulario
  2. Validación con Zod
  3. Petición POST a `/api/auth/login`
  4. Guarda datos en localStorage
  5. Redirige a home

#### Registro (`register.tsx`):
- **Validación**: Nombre mínimo 2 caracteres, email válido, password mínimo 6 caracteres, confirmación de password
- **Flujo**:
  1. Usuario llena formulario
  2. Validación con Zod (incluye confirmación de password)
  3. Petición POST a `/api/auth/register`
  4. Guarda datos en localStorage
  5. Redirige a home

### Autenticación:
- **Almacenamiento**: localStorage
- **Protección de rutas**: Verificación en useEffect
- **Logout**: Limpia localStorage y redirige a login
- **Persistencia**: Datos del usuario se mantienen entre sesiones

### Panel de administración (`home.tsx`):
- **Funcionalidades**:
  - Listar todos los usuarios
  - Crear nuevos usuarios
  - Editar usuarios existentes
  - Eliminar usuarios
  - Estadísticas básicas

- **Componentes utilizados**:
  - Tabla para mostrar usuarios
  - Diálogos modales para crear/editar/eliminar
  - Formularios con validación
  - Cards para estadísticas

### UI/UX:
- **Diseño responsive**: Adaptable a móviles y desktop
- **Componentes accesibles**: Basados en Radix UI
- **Feedback visual**: Loading states, mensajes de error
- **Navegación intuitiva**: Breadcrumbs y enlaces claros

---

## FLUJO COMPLETO DE LA APLICACIÓN

### 1. Registro de usuario:
1. Usuario accede a `/register`
2. Llena formulario con validación en tiempo real
3. Frontend envía datos al backend
4. Backend valida, hashea contraseña y guarda en DB
5. Usuario es redirigido al panel de administración

### 2. Login de usuario:
1. Usuario accede a `/login`
2. Ingresa credenciales
3. Backend verifica credenciales
4. Si son correctas, retorna datos del usuario
5. Frontend guarda datos y redirige al panel

### 3. Panel de administración:
1. Verifica si hay usuario autenticado
2. Si no hay, redirige a login
3. Carga lista de usuarios desde el backend
4. Permite gestionar usuarios (CRUD completo)

---

## COMANDOS ÚTILES

### Backend:
```bash
# Instalar dependencias
pnpm install

# Ejecutar en desarrollo
pnpm start

# Generar cliente Prisma
npx prisma generate

# Sincronizar esquema
npx prisma db push

# Ver base de datos (Prisma Studio)
npx prisma studio
```

### Frontend:
```bash
# Instalar dependencias
pnpm install

# Ejecutar en desarrollo
pnpm dev

# Build para producción
pnpm build

# Preview build
pnpm preview
```

---

## NOTAS IMPORTANTES

1. **Base de datos**: Asegúrate de tener MongoDB Atlas configurado
2. **Variables de entorno**: Configura correctamente el archivo `.env`
3. **Puertos**: Backend en 3000, Frontend en 5173
4. **CORS**: Configurado para permitir comunicación entre frontend y backend
5. **Seguridad**: Contraseñas hasheadas, validación de datos
6. **Logging**: Sistema de logs detallado en el backend

---

## SOLUCIÓN DE PROBLEMAS

### Error de conexión a MongoDB:
- Verificar URL de conexión en `.env`
- Verificar credenciales de MongoDB Atlas
- Ejecutar `npx prisma db push`

### Error de CORS:
- Verificar que el backend esté corriendo en puerto 3000
- Verificar configuración de CORS en `server.js`

### Error de validación:
- Revisar logs del backend
- Verificar formato de datos enviados
- Comprobar esquemas de validación

### Error de build del frontend:
- Verificar versiones de Node.js
- Limpiar cache: `pnpm clean`
- Reinstalar dependencias: `rm -rf node_modules && pnpm install` 